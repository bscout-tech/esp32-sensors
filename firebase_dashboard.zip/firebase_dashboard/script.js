import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getDatabase, ref, onValue } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const dataRef = ref(db, 'sensors/data');

// Setup charts
const tempChart = createLineChart('tempChart', 'Temperature (°C)');
const humChart = createLineChart('humChart', 'Humidity (%)');
const airChart = createLineChart('airChart', 'Air Quality (MQ135)');

function createLineChart(canvasId, label) {
  const ctx = document.getElementById(canvasId).getContext('2d');
  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: label,
        data: [],
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }]
    },
    options: {
      responsive: true,
      animation: false,
      scales: { x: { display: false }, y: { beginAtZero: true } }
    }
  });
}

function updateChart(chart, value) {
  const now = new Date().toLocaleTimeString();
  chart.data.labels.push(now);
  chart.data.datasets[0].data.push(value);
  if (chart.data.labels.length > 10) {
    chart.data.labels.shift();
    chart.data.datasets[0].data.shift();
  }
  chart.update();
}

function renderData(data) {
  document.getElementById("dataDisplay").innerHTML = `
    <p><strong>MQ6 (Gas):</strong> ${data.mq6}</p>
    <p><strong>MQ2 (Smoke):</strong> ${data.mq2}</p>
    <p><strong>MQ135 (Air Quality):</strong> ${data.mq135}</p>
    <p><strong>Analog 4:</strong> ${data.analog4}</p>
    <p><strong>Battery (%):</strong> ${data.battery}</p>
    <p><strong>eCO₂ (ppm):</strong> ${data.eco2}</p>
    <p><strong>TVOC (ppb):</strong> ${data.tvoc}</p>
    <p><strong>AHT Temp (°C):</strong> ${data.ahtTemp}</p>
    <p><strong>AHT Hum (%):</strong> ${data.ahtHum}</p>
    <p><strong>DHT Temp (°C):</strong> ${data.dhtTemp}</p>
    <p><strong>DHT Hum (%):</strong> ${data.dhtHum}</p>
    <p><strong>Latitude:</strong> ${data.latitude}</p>
    <p><strong>Longitude:</strong> ${data.longitude}</p>
  `;

  document.getElementById("status").innerHTML = `
    <span class="inline-block px-2 py-1 rounded ${
      data.deviceStatus === "online" ? "bg-green-200 text-green-800" : "bg-red-200 text-red-800"
    }">${data.deviceStatus?.toUpperCase() || "UNKNOWN"}</span>
    <span class="ml-2 text-gray-500">Last updated: ${data.timestamp || "N/A"}</span>
  `;

  updateChart(tempChart, data.dhtTemp);
  updateChart(humChart, data.dhtHum);
  updateChart(airChart, data.mq135);
}

// Realtime listener
onValue(dataRef, (snapshot) => {
  const data = snapshot.val();
  if (data) {
    renderData(data);
  } else {
    document.getElementById("dataDisplay").innerText = "No data available.";
  }
});
